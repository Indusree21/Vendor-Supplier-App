// ✅ Backend base URL
const BASE_URL = "http://localhost:5000";

// ✅ Get vendorId from localStorage (or fallback for testing)
const vendorId = localStorage.getItem("vendorId") || "1234567890";

// ✅ 1. Handle Sales Status Change
document.getElementById("salesStatus")?.addEventListener("change", async (e) => {
  const status = e.target.value;

  try {
    const res = await fetch(`${BASE_URL}/api/vendor/updateSalesStatus/${vendorId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ salesStatus: status })
    });

    const data = await res.json();
    console.log("Sales status updated:", data);
  } catch (error) {
    console.error("Error updating sales status:", error);
  }
});

// ✅ 2. Product Search and Recommendation
async function searchProduct() {
  const query = document.getElementById("searchInput").value;

  try {
    const res = await fetch(`${BASE_URL}/api/seller/search?query=${encodeURIComponent(query)}`);
    const data = await res.json();

    const salesStatus = document.getElementById("salesStatus").value;
    const recommendationMap = {
      busy: 100,
      normal: 60,
      slow: 30
    };

    const container = document.getElementById("results");
    container.innerHTML = "";

    if (data.length === 0) {
      container.innerHTML = "<p>No products found.</p>";
      return;
    }

    data.forEach(item => {
      const div = document.createElement("div");
      div.className = "product-card";
      div.innerHTML = `
        <h4>${item.productName}</h4>
        <p><strong>Supplier:</strong> ${item.sellerName}</p>
        <p><strong>Location:</strong> ${item.location}</p>
        <p><strong>Price:</strong> ₹${item.price}</p>
        <p><strong>Recommended Quantity:</strong> ${recommendationMap[salesStatus] || 0}</p>
        <button class="btn" onclick="placeOrder('${item._id}')">Order Now</button>
      `;
      container.appendChild(div);
    });
  } catch (error) {
    console.error("Error fetching products:", error);
  }
}

// ✅ 3. Place Order
async function placeOrder(productId) {
  try {
    const res = await fetch(`${BASE_URL}/api/order/placeOrder`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ vendorId, productId })
    });

    const data = await res.json();
    alert(data.message || "Order placed successfully!");
    loadOrders(); // Refresh order list
  } catch (error) {
    console.error("Error placing order:", error);
    alert("Order failed.");
  }
}

// ✅ 4. Load Vendor Orders
async function loadOrders() {
  try {
    const res = await fetch(`${BASE_URL}/api/order/vendorOrders/${vendorId}`);
    const orders = await res.json();

    const list = document.getElementById("orderList");
    list.innerHTML = "";

    orders.forEach(order => {
      const li = document.createElement("li");
      li.textContent = `${order.productName} - ₹${order.price} - Status: ${order.status}`;
      list.appendChild(li);
    });
  } catch (error) {
    console.error("Error loading orders:", error);
  }
}

// ✅ 5. Auto-load Orders on Page Load
if (document.getElementById("orderList")) {
  loadOrders();
}
