const express = require('express');
const cors = require('cors');
require('dotenv').config();

const vendorRoutes = require('./routes/vendorRoutes');
const sellerRoutes = require('./routes/sellerRoutes');

const orderRoutes = require('./routes/orderRoutes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/vendor', vendorRoutes);
app.use('/api/seller', sellerRoutes);
app.use('/api/orders', orderRoutes);

// Root Route
app.get('/', (req, res) => {
  res.send('🟢 Vendor Supply Backend is running');
});

// ✅ Correct export
module.exports = app;

 
