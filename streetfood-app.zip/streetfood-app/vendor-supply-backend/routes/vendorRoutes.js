const express = require('express');
const router = express.Router();

// Import vendor controller functions
const {
  sendOtp,
  verifyOtp,
  setLanguage,
  filterVendors,
  getAllVendors,
  registerVendor
} = require('../controllers/vendorController');

/**
 * ✅ Default route - Health check
 *    Useful to quickly check if the vendor API is running
 */
router.get('/', (req, res) => {
  res.send('✅ Vendor API is up and running!');
});

/**
 * ✅ Vendor listing routes
 */
router.get('/list', getAllVendors);      // Fetch all vendors
router.get('/filter', filterVendors);    // Filter vendors by city/area/pincode

/**
 * ✅ OTP / Authentication routes
 */
router.post('/send-otp', sendOtp);       // Send OTP to vendor
router.post('/verify-otp', verifyOtp);   // Verify OTP (creates minimal record if new)

/**
 * ✅ Profile management routes
 */
router.post('/register', registerVendor);     // Complete vendor profile
router.post('/set-language', setLanguage);    // Update preferred language

// Export the router
module.exports = router;

