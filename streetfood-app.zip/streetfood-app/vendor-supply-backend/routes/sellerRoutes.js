const express = require('express');
const router = express.Router();
const {
  sendOtp,
  verifyOtp,
  setLanguage,
  getAllSellers,
  registerSeller
} = require('../controllers/sellerController');

/**
 * ✅ Default health check
 */
router.get('/', (req, res) => {
  res.send('✅ Seller API is up and running!');
});

/**
 * ✅ Sellers list
 */
router.get('/list', getAllSellers);

/**
 * ✅ OTP routes
 */
router.post('/send-otp', sendOtp);
router.post('/verify-otp', verifyOtp);

/**
 * ✅ Profile actions
 */
router.post('/register', registerSeller);
router.post('/set-language', setLanguage);

module.exports = router;

