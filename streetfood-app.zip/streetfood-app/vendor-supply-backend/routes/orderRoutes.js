const express = require('express');
const router = express.Router();
const {
  createOrder,
  updateOrderStatus,
  listOrders,
  getOrderById
} = require('../controllers/orderController');

router.get('/', (req, res) => res.send('✅ Order API is up and running!'));
router.get('/list', listOrders);         // Get all orders
router.get('/:id', getOrderById);        // Get order by ID (optional)
router.post('/', createOrder);           // Create a new order
router.post('/:id/status', updateOrderStatus);  // Update order status

module.exports = router;

