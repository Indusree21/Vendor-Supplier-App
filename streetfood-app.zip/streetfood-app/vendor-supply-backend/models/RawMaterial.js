// models/RawMaterial.js
const mongoose = require("mongoose");

const rawMaterialSchema = new mongoose.Schema({
  productName: String,
  price: Number,
  location: String,
  sellerName: String,
  sellerPhone: String, // associate with seller for lookup
  uploadedAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("RawMaterial", rawMaterialSchema);
