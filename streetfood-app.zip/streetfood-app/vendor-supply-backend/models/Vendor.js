const mongoose = require('mongoose');

// Vendor Schema
const vendorSchema = new mongoose.Schema(
  {
    // Phone number is required and unique (acts as login identifier)
    phone: {
      type: String,
      required: true,
      unique: true
    },

    // Vendor name (optional at OTP stage, required at profile completion)
    name: {
      type: String
    },

    // Shop name
    shopName: {
      type: String
    },

    // Preferred language
    language: {
      type: String,
      enum: ['en', 'hi'],
      default: 'en'
    },

    // Vendor location (city, area, pincode)
    location: {
      city: { type: String },
      area: { type: String },
      pincode: { type: String }
    }
  },
  { timestamps: true } // Adds createdAt and updatedAt
);

// Export model
module.exports = mongoose.model('Vendor', vendorSchema);
