const mongoose = require('mongoose');

const sellerSchema = new mongoose.Schema(
  {
    phone: {
      type: String,
      required: true,
      unique: true
    },
    name: {
      type: String
    },
    language: {
      type: String,
      enum: ['en', 'hi'],
      default: 'en'
    },
    location: {
      type: String // simple string (city/area)
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Seller', sellerSchema);
