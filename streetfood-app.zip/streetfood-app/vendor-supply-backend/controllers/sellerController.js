const Seller = require('../models/Seller');

/**
 * ✅ Send OTP (static for testing)
 */
exports.sendOtp = async (req, res) => {
  const { phone } = req.body;

  if (!phone) {
    return res.status(400).json({ error: 'Phone number required' });
  }

  return res.status(200).json({
    message: 'OTP sent successfully',
    otp: '123456'
  });
};

/**
 * ✅ Verify OTP (create minimal seller if new)
 */
exports.verifyOtp = async (req, res) => {
  const { phone, otp } = req.body;

  if (!phone || !otp) {
    return res.status(400).json({ error: 'Phone and OTP required' });
  }

  if (otp !== '123456') {
    return res.status(401).json({ error: 'Invalid OTP' });
  }

  try {
    let seller = await Seller.findOne({ phone });

    // Create minimal seller if not exists
    if (!seller) {
      seller = new Seller({ phone });
      await seller.save();
    }

    return res.status(200).json({
      message: 'OTP verified',
      sellerId: seller._id
    });
  } catch (err) {
    console.error('verifyOtp error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
};

/**
 * ✅ Register / Complete profile (Update if exists)
 */
exports.registerSeller = async (req, res) => {
  const { name, phone, location } = req.body;

  if (!name || !phone || !location) {
    return res
      .status(400)
      .json({ error: 'name, phone, location are required' });
  }

  try {
    let seller = await Seller.findOne({ phone });

    // If seller already exists from OTP step → update profile
    if (seller) {
      seller.name = name;
      seller.location = location;
      await seller.save();

      return res.status(200).json({
        message: 'Seller profile updated successfully',
        seller
      });
    }

    // Edge case: Seller doesn't exist (create new)
    seller = new Seller({ name, phone, location });
    await seller.save();

    return res.status(201).json({
      message: 'Seller registered successfully',
      seller
    });
  } catch (err) {
    console.error('registerSeller error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
};

/**
 * ✅ Set language
 */
exports.setLanguage = async (req, res) => {
  const { phone, language } = req.body;

  if (!phone || !language) {
    return res
      .status(400)
      .json({ error: 'Phone and language are required' });
  }

  try {
    const seller = await Seller.findOneAndUpdate(
      { phone },
      { language },
      { new: true }
    );

    if (!seller) {
      return res.status(404).json({ error: 'Seller not found' });
    }

    return res.status(200).json({
      message: 'Language updated successfully',
      seller
    });
  } catch (err) {
    console.error('setLanguage error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
};

/**
 * ✅ Get all sellers
 */
exports.getAllSellers = async (req, res) => {
  try {
    const sellers = await Seller.find().sort({ createdAt: -1 });
    return res.json(sellers);
  } catch (err) {
    console.error('getAllSellers error:', err);
    return res.status(500).json({ error: 'Failed to fetch sellers' });
  }
};
