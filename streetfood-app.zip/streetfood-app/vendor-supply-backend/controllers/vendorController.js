const Vendor = require('../models/Vendor');

/**
 * ✅ Send OTP (static for testing)
 */
exports.sendOtp = async (req, res) => {
  const { phone } = req.body;

  if (!phone) {
    return res.status(400).json({ error: 'Phone number required' });
  }

  // Simulate OTP (static for dev/testing)
  return res.status(200).json({
    message: 'OTP sent successfully',
    otp: '123456' // ⚠️ Replace with real SMS in production
  });
};

/**
 * ✅ Verify OTP (creates vendor if missing)
 */
exports.verifyOtp = async (req, res) => {
  const { phone, otp } = req.body;

  if (!phone || !otp) {
    return res.status(400).json({ error: 'Phone and OTP required' });
  }

  if (otp !== '123456') {
    return res.status(401).json({ error: 'Invalid OTP' });
  }

  try {
    let vendor = await Vendor.findOne({ phone });

    if (!vendor) {
      console.log("Creating new vendor with phone:", phone);
      vendor = new Vendor({ phone });
      await vendor.save();
    }

    return res.status(200).json({
      message: 'OTP verified',
      vendorId: vendor._id
    });
  } catch (err) {
    console.error('verifyOtp error (full):', err);
    return res.status(500).json({
      error: 'Server error',
      details: err.message
    });
  }
};



/**
 * ✅ Register / complete vendor profile
 */
exports.registerVendor = async (req, res) => {
  const { name, shopName, phone, location } = req.body;

  // location must have city, area, pincode
  if (!name || !shopName || !phone || !location) {
    return res
      .status(400)
      .json({ error: 'name, shopName, phone, location are required' });
  }

  try {
    let existing = await Vendor.findOne({ phone });

    // If vendor exists, update profile (idempotent)
    if (existing) {
      existing.name = name;
      existing.shopName = shopName;
      existing.location = {
        city: location.city || existing.location?.city,
        area: location.area || existing.location?.area,
        pincode: location.pincode || existing.location?.pincode
      };
      const saved = await existing.save();
      return res
        .status(200)
        .json({ message: 'Vendor profile updated', vendor: saved });
    }

    // Otherwise create full record (edge case)
    const vendor = new Vendor({
      name,
      shopName,
      phone,
      location
    });
    await vendor.save();

    return res
      .status(201)
      .json({ message: 'Vendor registered successfully', vendor });
  } catch (err) {
    console.error('registerVendor error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
};

/**
 * ✅ Set language (en/hi)
 */
exports.setLanguage = async (req, res) => {
  const { phone, language } = req.body;

  if (!phone || !language) {
    return res
      .status(400)
      .json({ error: 'Phone and language are required' });
  }

  try {
    const vendor = await Vendor.findOneAndUpdate(
      { phone },
      { language },
      { new: true }
    );

    if (!vendor) {
      return res.status(404).json({ error: 'Vendor not found' });
    }

    return res
      .status(200)
      .json({ message: 'Language updated successfully', vendor });
  } catch (err) {
    console.error('setLanguage error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
};

/**
 * ✅ Filter vendors by city, area or pincode
 */
exports.filterVendors = async (req, res) => {
  try {
    const { city, area, pincode } = req.query;
    const filter = {};

    if (city) filter['location.city'] = city;
    if (area) filter['location.area'] = area;
    if (pincode) filter['location.pincode'] = pincode;

    const vendors = await Vendor.find(filter);
    return res.json(vendors);
  } catch (err) {
    console.error('filterVendors error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
};

/**
 * ✅ List all vendors
 */
exports.getAllVendors = async (req, res) => {
  try {
    const vendors = await Vendor.find().sort({ createdAt: -1 });
    return res.json(vendors);
  } catch (err) {
    console.error('getAllVendors error:', err);
    return res.status(500).json({ error: 'Failed to fetch vendors' });
  }
};

