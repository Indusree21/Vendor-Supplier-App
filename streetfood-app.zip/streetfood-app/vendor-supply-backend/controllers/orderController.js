const Order = require('../models/Order');

// ✅ Create a new order
exports.createOrder = async (req, res) => {
  try {
    const { vendorId, sellerId, items, totalAmount } = req.body;

    if (!vendorId || !sellerId || !items || items.length === 0 || !totalAmount) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const newOrder = new Order({
      vendorId,
      sellerId,
      items,
      totalAmount,
      status: 'pending'
    });

    await newOrder.save();

    res.status(201).json({
      message: 'Order created successfully',
      order: newOrder
    });
  } catch (err) {
    console.error('createOrder error:', err);
    res.status(500).json({ error: 'Failed to create order' });
  }
};

// ✅ List all orders
exports.listOrders = async (req, res) => {
  try {
    const orders = await Order.find()
      .populate('vendorId')
      .populate('sellerId')
      .sort({ createdAt: -1 });

    res.json(orders);
  } catch (err) {
    console.error('listOrders error:', err);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
};

// ✅ Get order by ID (optional for future)
exports.getOrderById = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('vendorId')
      .populate('sellerId');

    if (!order) return res.status(404).json({ error: 'Order not found' });

    res.json(order);
  } catch (err) {
    console.error('getOrderById error:', err);
    res.status(500).json({ error: 'Failed to fetch order' });
  }
};

// ✅ Update order status
exports.updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;
    if (!status) {
      return res.status(400).json({ error: 'Status is required' });
    }

    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    )
      .populate('vendorId')
      .populate('sellerId');

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    res.json({
      message: 'Order status updated',
      order
    });
  } catch (err) {
    console.error('updateOrderStatus error:', err);
    res.status(500).json({ error: 'Failed to update order status' });
  }
};
